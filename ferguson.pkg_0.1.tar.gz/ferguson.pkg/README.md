# ferguson.pkg
## An R package for processing crab data 

This R package is for processing crab data. The functions used are intended 
to better understand Maryland crabs and allow users to calculate a variety of data. Users
should be able to clean their data, make a variety of different plots, as well as manipulate their data in some form or another. 
